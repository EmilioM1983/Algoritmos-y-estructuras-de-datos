package com.danielblanco.algoritmosestructuras._00_linkedlist;

public class Node {
  public Node next;
  public int value;

  public Node(int value) {
    this.value = value;
  }
}
