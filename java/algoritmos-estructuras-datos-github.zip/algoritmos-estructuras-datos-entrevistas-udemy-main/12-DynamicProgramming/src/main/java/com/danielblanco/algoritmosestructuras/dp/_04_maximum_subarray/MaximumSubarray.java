package com.danielblanco.algoritmosestructuras.dp._04_maximum_subarray;

/*
 * Dado un array de enteros, encuentra el subarray con la mayor suma y devuelve dicha suma.
 *
 * Ejemplo 1:
 *  Input:
 *    [-2,1,-3,4,-1,2,1,-5,4]
 *  Output:
 *    6 (subarray [4,-1,2,1])
 *
 * Ejemplo 2:
 *  Input:
 *    [5,4,-1,7,8]
 *  Output:
 *    23 (subarray [5,4,-1,7,8], es decir, el array entero)
 *
 */
public class MaximumSubarray {

  public int maxSubArray(int[] nums) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
