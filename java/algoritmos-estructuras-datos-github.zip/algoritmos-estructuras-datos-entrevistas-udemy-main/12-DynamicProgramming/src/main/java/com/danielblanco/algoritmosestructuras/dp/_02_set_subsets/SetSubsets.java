package com.danielblanco.algoritmosestructuras.dp._02_set_subsets;

import java.util.List;

/*
 * Implementa un método para devolver todos los subconjuntos de un conjunto de enteros
 * Ejemplo:
 *  Input: [1,2,3]
 *
 *  Output:
 *    [
 *      [1,2,3],
 *      [1,2],
 *      [1,3],
 *      [2,3],
 *      [1],
 *      [2],
 *      [3],
 *      []
 *    ]
 */
public class SetSubsets {

  List<List<Integer>> subsets(List<Integer> set) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
