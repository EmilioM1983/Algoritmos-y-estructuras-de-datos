package com.danielblanco.algoritmosestructuras.extra._04_longest_unique_substring;

/*
 * Dada una string, devuelve la longitud de la substring más larga
 * en la que no se repiten caracteres
 *
 * Ejemplo 1:
 *  Input: aabcdefed
 *  Output: 6 (abcdef)
 *
 * Ejemplo 2:
 *  Input: ccccc
 *  Output: 1 (c)
 */
public class LongestUniqueSubstring {

  public int lengthOfLongestSubstring(String s) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
