package com.danielblanco.algoritmosestructuras.extra._02_word_break;

import java.util.List;

/*
 * Dada una string s y un diccionario de palabras wordDict, devuelve si s puede ser dividida usando
 * solamente palabras de wordDict.
 *
 * Ejemplo 1:
 *  Input:
 *    s: "applepenapple"
 *    wordDict: ["apple","pen"]
 *
 *  Output: true
 *
 * Ejemplo 2:
 *  Input:
 *    s: "catsandog"
 *    wordDict: ["cats","dog","sand","and","cat"]
 *
 *  Output: false
 */
public class WordBreak {

  public boolean wordBreak(String s, List<String> wordDict) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
