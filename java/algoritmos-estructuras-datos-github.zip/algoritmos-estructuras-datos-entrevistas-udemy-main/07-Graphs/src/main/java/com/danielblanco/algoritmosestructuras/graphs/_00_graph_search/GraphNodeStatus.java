package com.danielblanco.algoritmosestructuras.graphs._00_graph_search;

public enum GraphNodeStatus {
  Unvisited,
  Visited,
  Visiting
}
