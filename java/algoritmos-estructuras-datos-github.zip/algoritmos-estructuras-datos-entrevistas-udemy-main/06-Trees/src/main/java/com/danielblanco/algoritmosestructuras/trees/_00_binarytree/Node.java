package com.danielblanco.algoritmosestructuras.trees._00_binarytree;

public class Node {
  public int value;
  public Node left;
  public Node right;

  public Node(int value) {
    this.value = value;
  }
}
