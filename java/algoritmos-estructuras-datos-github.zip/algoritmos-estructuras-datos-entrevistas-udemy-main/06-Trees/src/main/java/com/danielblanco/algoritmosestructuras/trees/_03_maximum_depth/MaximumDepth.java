package com.danielblanco.algoritmosestructuras.trees._03_maximum_depth;

import com.danielblanco.algoritmosestructuras.trees._00_binarytree.Node;

/*
 * Dada la raíz de un árbol binario, devuelve su profundidad máxima.
 *
 * Ejemplo:
 *  Input:
 *         4
 *      2     7
 *    1   3
 *  8
 *
 *  Output: 4
 */
public class MaximumDepth {

  public int maxDepth(Node root) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
