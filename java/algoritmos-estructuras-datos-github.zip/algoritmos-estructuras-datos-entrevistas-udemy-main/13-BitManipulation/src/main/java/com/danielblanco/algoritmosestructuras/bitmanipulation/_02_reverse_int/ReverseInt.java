package com.danielblanco.algoritmosestructuras.bitmanipulation._02_reverse_int;

/*
 * Dado un entero, devuelve el entero que representa el valor en binario inverso.
 *
 * Ejemplo 1:
 *  Input: -5 (11111111111111111111111111111011)
 *  Output: 3221225471 (11011111111111111111111111111111)
 *
 * Ejemplo 2:
 *  Input: 43261596 (00000010100101000001111010011100)
 *  Output: 964176192 (00111001011110000010100101000000)
 */
public class ReverseInt {

  public int reverseBits(int n) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
