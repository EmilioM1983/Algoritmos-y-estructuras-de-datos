package com.danielblanco.algoritmosestructuras.bitmanipulation._04_sum_integers;

/*
 * Dados dos enteros, devuelve la suma de ambos sin utilizar los operadores '+' o '-'
 *
 * Ejemplo:
 *  Input:
 *    a: 2
 *    b: 5
 *  Output: 7
 */
public class SumIntegers {

  public int getSum(int a, int b) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
