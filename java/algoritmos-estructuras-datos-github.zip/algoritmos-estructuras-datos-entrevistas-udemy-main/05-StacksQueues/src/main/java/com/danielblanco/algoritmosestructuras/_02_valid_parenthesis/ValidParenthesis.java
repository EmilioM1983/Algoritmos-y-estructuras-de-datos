package com.danielblanco.algoritmosestructuras._02_valid_parenthesis;

/*
 * Dado un String que solamente contiene los caracteres '(', ')', '{', '}', '[' y ']',
 * implementa un algoritmo para determinar si es válido.
 *
 * Ejemplo 1:
 *  Input: "([]){}"
 *  Output: true
 *
 * Ejemplo 2:
 *  Input: "({)}"
 *  Output: false
 */
public class ValidParenthesis {

  public boolean isValid(String s) {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
