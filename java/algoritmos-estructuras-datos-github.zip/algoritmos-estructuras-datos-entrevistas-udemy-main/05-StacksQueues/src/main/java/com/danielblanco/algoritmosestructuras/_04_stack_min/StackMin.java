package com.danielblanco.algoritmosestructuras._04_stack_min;

/*
 * ¿Cómo diseñarías un Stack que además de las operaciones de push y pop también
 * contase con una operación para obtener el mínimo?
 */
public class StackMin {

  public void push(Integer data) {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  public int pop() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  public int min() {
    throw new UnsupportedOperationException("Not implemented yet");
  }
}
