package com.danielblanco.algoritmosestructuras._00_stackqueue;

public class MyEmptyQueueException extends RuntimeException {}
