package com.danielblanco.algoritmosestructuras._00_stackqueue;

public class MyEmptyStackException extends RuntimeException {}
